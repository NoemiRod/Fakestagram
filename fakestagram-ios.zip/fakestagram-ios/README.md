# fakestagram-ios

[![Build Status](https://travis-ci.org/iOSLabUNAM/fakestagram-ios.svg?branch=master)](https://travis-ci.org/iOSLabUNAM/fakestagram-ios)

Sample application
