//
//  fakestagramTests.swift
//  fakestagramTests
//
//  Created by LuisE on 3/16/19.
//  Copyright © 2019 3zcurdia. All rights reserved.
//

import XCTest
@testable import fakestagram

class fakestagramTests: XCTestCase {

    func testExample() {
        XCTAssert(true)
    }

}
