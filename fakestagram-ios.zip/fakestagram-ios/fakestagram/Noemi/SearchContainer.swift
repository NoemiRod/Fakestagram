//
//  SearchContainer.swift
//  fakestagram
//
//  Created by Noemí Rod on 8/8/19.
//  Copyright © 2019 3zcurdia. All rights reserved.
//

import Foundation

class SearchContainer {
    
    //Arreglo vacío
    public var arrayContainer = [Post]()
    //Se crea un objeto para acceder a el a través de shared
    static let shared = SearchContainer()
    
    func addItem(item:Post) {
        arrayContainer.append(item)
    }
    
    func addFeed(feed: [Post]) {
        self.arrayContainer = feed
    }
    
    func removeItem(index:Int) {
        arrayContainer.remove(at: index)
    }
    
    func showSearch() -> [Post] {
        return arrayContainer
    }
    
    func removeAllItems() {
        arrayContainer.removeAll()
    }
}
