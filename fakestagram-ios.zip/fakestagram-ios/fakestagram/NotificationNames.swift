//
//  NotificationNames.swift
//  fakestagram
//
//  Created by LuisE on 5/3/19.
//  Copyright © 2019 3zcurdia. All rights reserved.
//

import Foundation

extension Notification.Name {
    static let didLikePost = Notification.Name("didLikePost")
}
